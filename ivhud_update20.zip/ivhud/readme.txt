Where to put this hud :
C:\Program Files (x86)\Steam\steamapps\common\Team Fortress 2\tf\custom