Crosshairs and Hitmarkers
By errur
http://steamcommunity.com/id/sergiuung
======================================
All crosshairs and hitmarkers are custom and use textures not fonts. They will work on servers with sv_pure set to 1 and 2 though.
Custom crosshairs use the achivement tracker to be displayed so using this will break the tracker so it doesn't show achievements on screen anymore.

First go to scripts/hudlayout.res and open it with a notepad. Scroll down to the very end and paste in this:

	"Hitmarkers"
	{
		"ControlName"	"CTFImagePanel"
		"fieldName"		"Hitmarkers"
		"xpos"			"c-25"
		"ypos"			"c-25"
		"zpos"			"3"
		"wide"			"0"
		"tall"			"0"
		"visible"		"1"
		"enabled"		"1"
		"image"			"replay/thumbnails/hitmarkers"
		"scaleImage"	"0"
	}
	
Paste it right before the final }
============================================================
The end of the file should look like this:
	"Hitmarkers"
	{
		"ControlName"	"CTFImagePanel"
		"fieldName"		"Hitmarkers"
		"xpos"			"c-25"
		"ypos"			"c-25"
		"zpos"			"3"
		"wide"			"0"
		"tall"			"0"
		"visible"		"1"
		"enabled"		"1"
		"image"			"replay/thumbnails/hitmarkers"
		"scaleImage"	"0"
	}
}
============================================================ < this line not included

To select a crosshair or a hitmarker open Crosshairs.png or Hitmarkers.png and pick one. 
Next go to materials/vgui/replay/thumbnails and open up crosshairs.vtf or hitmarkers.vmt with a text editor. 
Replace "$basetexture" "vgui\replay\thumbnails\crosshairs\crosshair_circle_dot" with the crosshair you want. Only the name on the end needs to be changed.
So for example if you want crosshair_T_dot you'll need to change it to: "$basetexture" "vgui\replay\thumbnails\crosshairs\crosshair_T_dot" 
Same process for hitmarkers.

Because crosshairs use the achievement tracker you can display and hide it using the hud_achievement_tracker 0 and 1 commands. 
They don't hide the default crosshair.