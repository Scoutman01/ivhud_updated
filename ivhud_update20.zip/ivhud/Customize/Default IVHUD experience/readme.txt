animated heart health
courier new damage font
mini health and ammo for animated heart